<template>
    <div>
        <div class="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header-panel">
                            <ul class="main-nav">
                                <li class="active"><a href="#">Home</a></li>
                                <li><a href="#">Explore</a></li>
                                <li><a href="#">Request listing</a></li>
                                <li><a href="#"><i class="fa fa-user-o"></i>Sign in</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "FooterSection"
    }
</script>

<style scoped>

</style>