<template>
    <div>
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="footer-panel">
                            <div class="foot-txt">
                                <p>&copy;Copyright 2018. All Rights Reserved.</p>
                            </div>
                            <ul class="social-nav d-inline">
                                <li class="facebook">
                                    <a href="#"><i class="fa fa-facebook-official"></i></a>
                                </li>
                                <li class="instagram">
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </li>
                                <li class="twitter">
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                </li>
                                <li class="youtube">
                                    <a href="#"><i class="fa fa-youtube-play"></i></a>
                                </li>
                            </ul>
                            <ul class="foot-nav d-inline">
                                <li><a href="#">Trust and Safety</a></li>
                                <li><a href="#">Terms of Use</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Footer"
    }
</script>

<style scoped>

</style>